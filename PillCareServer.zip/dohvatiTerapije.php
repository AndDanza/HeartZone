<?php
    include("baza.class.php");
	
    $veza = new Baza();
    $veza->spojiDB();
    
	$user_id = $_GET["user_id"];
	
    $podaci = array();
    
    if(isset($user_id)){
        $sql = "SELECT lijek.naziv, terapija.pojedinacna_doza from terapija, lijek where lijek.id = terapija.lijek_id and terapija.korisnik_id = '.$user_id.' and terapija.kraj IS null;";
    
        $rezultat = $veza->selectDB($sql);
        while ($red = $rezultat->fetch_array()) {
            $podaci["naziv_lijeka"] = $red["naziv"];
            $podaci["pojedinacna_doza"] = $red["pojedinacna_doza"];
        }
        
        if (json_encode($podaci)!='[]'){
            echo json_encode($podaci,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        }
        else{
            header('HTTP/1.1 400 Bad request', true, 400);
        }
    }
    $veza->zatvoriDB();