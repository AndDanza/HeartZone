<?php
    include("baza.class.php");
    $veza = new Baza();
    $veza->spojiDB();
    
    $therapy_id = $_GET['therapy_id'];
    $start = $_GET["start"];
    $date = $_GET["date"];
    
    if(isset($therapy_id) && isset($start)){
        $sql;
        if($start == "1")
            $sql = "UPDATE `terapija` SET `pocetak` = '$date' WHERE `id` = $therapy_id 
                    AND `pocetak` IS NULL AND `kraj` IS NULL";
        else 
            $sql = "UPDATE `terapija` SET `kraj` = '$date' WHERE `id` = $therapy_id AND `kraj` IS NULL";
        $rezultat = $veza->updateDB($sql);
        if($veza->pogreskaDB()){
            header('HTTP/1.1 400 Bad request', true, 400);
        }
        else{
            header('HTTP/1.1 200 OK', true, 200);
            echo "{'response': '1'}";
        }
    }
    else{
        header('HTTP/1.1 400 Bad request', true, 400);
    }
    $veza->zatvoriDB();