<?php
    include("baza.class.php");
    $veza = new Baza();
    $veza->spojiDB();
    $username = $_GET["username"];
    $email = $_GET["email"];
    $exists=false;
    if (isset($username) && isset($email)) {
        $sql = "SELECT * FROM korisnik WHERE korisnicko_ime='$username' or email='$email'";
        $rezultat = $veza->selectDB($sql);
        while ($red = $rezultat->fetch_array()) {
            $exists=true;
        }
        if ($exists){
            header('HTTP/1.1 200 OK', true, 200);
            echo "{'response': '1'}";
        }
        else{
            header('HTTP/1.1 400 Bad request', true, 400);
        }
    }
    else
        header('HTTP/1.1 400 Bad request', true, 400);
    $veza->zatvoriDB();