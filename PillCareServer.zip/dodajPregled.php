<?php
    include("baza.class.php");
    $veza = new Baza();
    $veza->spojiDB();
    
    $appointment = json_decode($_GET['appointment']);
    
    if(isset($appointment)){
        $sql = "INSERT into pregled (termin, biljeska, vrijeme_upozorenja, aktivan, korisnik_id) 
        values ('$appointment->termin', '$appointment->biljeska', '$appointment->vrijemeUpozorenja', '$appointment->aktivan', $appointment->korisnikId)";
        $rezultat = $veza->updateDB($sql);
        
        if($veza->pogreskaDB()){
            header('HTTP/1.1 400 Bad request', true, 400);
        }
        else{
            header('HTTP/1.1 200 OK', true, 200);
            echo "{'response': '1'}";
        }
    }
    else{
        header('HTTP/1.1 400 Bad request', true, 400);
    }
    $veza->zatvoriDB();