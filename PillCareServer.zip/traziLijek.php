<?php
    include("baza.class.php");
	
    $veza = new Baza();
    $veza->spojiDB();
    
	$med_id = $_GET["med_id"];
	
    $podaci = array();
    
    if(isset($med_id)){
        $sql = "SELECT lj.id AS id, lj.barkod AS barkod, lj.naziv AS naziv, lj.jacina AS jacina, lj.broj_tableta AS broj_tableta, lj.pakiranje AS pakiranje, lj.upute AS upute, lj.proizvodac_id AS proizvodac_id FROM lijek AS lj WHERE lj.barkod = '".$med_id."'";
    
        $rezultat = $veza->selectDB($sql);
        while ($red = $rezultat->fetch_array()) {
            $podaci["id"] = $red["id"];
            $podaci["barkod"] = $red["barkod"];
            $podaci["naziv"] = $red["naziv"];
			$podaci["jacina"] = $red["jacina"];
			$podaci["broj_tableta"] = $red["broj_tableta"];
			$podaci["proizvodac_id"] = $red["proizvodac_id"];
			$podaci["pakiranje"] = $red["pakiranje"];
			$podaci["upute"] = $red["upute"];
        }
        
        if (json_encode($podaci)!='[]'){
            echo json_encode($podaci,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        }
        else{
            header('HTTP/1.1 400 Bad request', true, 400);
        }
    }
    $veza->zatvoriDB();