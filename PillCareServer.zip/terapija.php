<?php
    include("baza.class.php");
	
    $veza = new Baza();
    $veza->spojiDB();
	
	$user_id = $_GET["user"];
	
    $podaci = array();
    $allData = array();
    
    if(isset($user_id)){
        $sql="SELECT `lijek_id`,`pocetak`,`kraj`,`pojedinacna_doza`,`broj_dnevnih_doza`,`aktivna`,`upozorenje`,`razmak_dnevnih_doza` FROM `terapija` WHERE `korisnik_id` = $user_id";
    
        $rezultat = $veza->selectDB($sql);
        while ($red = $rezultat->fetch_array()) {
            $podaci["lijek_id"] = $red["lijek_id"];
            $podaci["pocetak"] = $red["pocetak"];
			$podaci["kraj"] = $red["kraj"];
			$podaci["pojedinacna_doza"] = $red["pojedinacna_doza"];
			$podaci["broj_dnevnih_doza"] = $red["broj_dnevnih_doza"];
			$podaci["aktivna"] = $red["aktivna"];
			$podaci["upozorenje"] = $red["upozorenje"];
			$podaci["razmak_dnevnih_doza"] = $red["razmak_dnevnih_doza"];
			
			$allData[] = $podaci;
        }
        
        if (json_encode($allData)!='[]'){
            echo json_encode($allData,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        }
        else{
            header('HTTP/1.1 400 Bad request', true, 400);
        }
    }
    $veza->zatvoriDB();