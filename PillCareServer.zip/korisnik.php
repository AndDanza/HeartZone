<?php
    include("baza.class.php");
    $veza = new Baza();
    $veza->spojiDB();
    $username = $_GET["username"];
    $podaci = array();
    if (isset($username)) {
        $sql = "SELECT id,ime,prezime,email,korisnicko_ime,lozinka FROM korisnik WHERE korisnicko_ime='$username'";
        $rezultat = $veza->selectDB($sql);
        while ($red = $rezultat->fetch_array()) {
            $podaci["id"] = $red["id"];
            $podaci["ime"] = $red["ime"];
            $podaci["prezime"] = $red["prezime"];
            $podaci["email"] = $red["email"];
            $podaci["korisnicko_ime"] = $red["korisnicko_ime"];
            $podaci["lozinka"] = $red["lozinka"];
        }
        if (json_encode($podaci)!='[]'){
            echo json_encode($podaci,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        }
        else{
            header('HTTP/1.1 400 Bad request', true, 400);
        }
    }
    $veza->zatvoriDB();