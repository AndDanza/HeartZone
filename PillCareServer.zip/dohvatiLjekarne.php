<?php

$host = "https://maps.googleapis.com/maps/api/place/nearbysearch/json";

$params = "?";
$params .= "type=pharmacy";
$params .= "&location=" . strval($_GET["location"]);
$params .= "&radius=5000&";
$params .= "key=AIzaSyBYDyHNHN3yo0-zZnka477oBt_rePb1gZ0";

// create a new cURL resource
$ch = curl_init();
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

// set URL and other appropriate options
curl_setopt($ch, CURLOPT_URL, $host . $params);
curl_setopt($ch, CURLOPT_HEADER, 0);

// grab URL and pass it to the browser
$json_parse = curl_exec($ch);

// close cURL resource, and free up system resources
curl_close($ch);

$json = json_decode($json_parse, true);
$arrayCount = count($json["results"]);

$podaci = [];
$ljekarna = [];

for ($i = 0; $i < $arrayCount; $i++) {
    $ljekarna["latitude"] = $json["results"][$i]["geometry"]["location"]["lat"];
    $ljekarna["longitude"] = $json["results"][$i]["geometry"]["location"]["lng"];
    $ljekarna["name"] = $json["results"][$i]["name"];

    if (isset($json["results"][$i]["opening_hours"])) {
        if ($json["results"][$i]["opening_hours"]["open_now"] == false) {
            $ljekarna["open"] = 0;
        } else if ($json["results"][$i]["opening_hours"]["open_now"] == true) {
            $ljekarna["open"] = 1;
        }
    } else {
        $ljekarna["open"] = -1;
    }
    $ljekarna["address"] = $json["results"][$i]["vicinity"];

    $podaci[] = $ljekarna;
}

if (json_encode($podaci) != '[]') {
    echo json_encode($podaci,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
} else {
    header('HTTP/1.1 400 Bad request', true, 400);
}
