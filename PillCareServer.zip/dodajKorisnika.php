<?php
    include("baza.class.php");
    $veza = new Baza();
    $veza->spojiDB();
    
    $user = json_decode($_GET['user']);
    $updateUser = json_decode($_GET['update']);
    
    if(isset($user) || isset($updateUser)){
        if(isset($user))
            $sql = "INSERT into korisnik (ime, prezime, email, korisnicko_ime, lozinka) 
            values ('$user->ime', '$user->prezime', '$user->email', '$user->korisnickoIme', '$user->lozinka')";
        if(isset($updateUser))
            $sql = "UPDATE `korisnik` SET `ime`='$updateUser->ime',`prezime`='$updateUser->prezime',`email`='$updateUser->email',`korisnicko_ime`='$updateUser->korisnickoIme',`lozinka`='$updateUser->lozinka' WHERE `id` =". intval($updateUser->id);
        $rezultat = $veza->updateDB($sql);
        if($veza->pogreskaDB()){
            header('HTTP/1.1 400 Bad request', true, 400);
        }
        else{
            header('HTTP/1.1 200 OK', true, 200);
            echo "{'response': '1'}";
        }
    }
    else{
        header('HTTP/1.1 400 Bad request', true, 400);
    }
    $veza->zatvoriDB();