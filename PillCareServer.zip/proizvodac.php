<?php
    include("baza.class.php");
	
    $veza = new Baza();
    $veza->spojiDB();
	
	$typeOfData = $_GET["type"];
	
    $podaci = array();
    $allData = array();
    
    if(isset($typeOfData)){
        if($typeOfData == "all")
        $sql="SELECT `id`,`naziv`,`slika` FROM `proizvodac`";
    
        $rezultat = $veza->selectDB($sql);
        while ($red = $rezultat->fetch_array()) {
            $podaci["id"] = $red["id"];
            $podaci["naziv"] = $red["naziv"];
			$podaci["slika"] = $red["slika"];
			
			$allData[] = $podaci;
        }
        
        if (json_encode($allData)!='[]'){
            echo json_encode($allData,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        }
        else{
            header('HTTP/1.1 400 Bad request', true, 400);
        }
    }
    $veza->zatvoriDB();