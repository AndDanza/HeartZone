<?php
    include("baza.class.php");
	
    $veza = new Baza();
    $veza->spojiDB();
    
	$user_id = $_GET["user_id"];
	
    $podaci = array();
    $allData = array();
    
    if(isset($user_id)){
        $sql="SELECT lj.id AS id, lj.barkod AS barkod, lj.naziv AS naziv, lj.jacina AS jacina, lj.broj_tableta AS broj_tableta, lj.pakiranje AS pakiranje, lj.upute AS upute, lj.proizvodac_id AS proizvodac_id FROM terapija JOIN lijek AS lj ON lj.id = terapija.lijek_id WHERE terapija.korisnik_id = $user_id AND terapija.kraj IS NULL";
    
        $rezultat = $veza->selectDB($sql);
        while ($red = $rezultat->fetch_array()) {
            $podaci["id"] = $red["id"];
            $podaci["barkod"] = $red["barkod"];
            $podaci["naziv"] = $red["naziv"];
			$podaci["jacina"] = $red["jacina"];
			$podaci["broj_tableta"] = $red["broj_tableta"];
			$podaci["proizvodac_id"] = $red["proizvodac_id"];
			$podaci["pakiranje"] = $red["pakiranje"];
			$podaci["upute"] = $red["upute"];
			
			$allData[] = $podaci;
        }
        
        if (json_encode($allData)!='[]'){
            echo json_encode($allData,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        }
        else{
            header('HTTP/1.1 400 Bad request', true, 400);
        }
    }
    $veza->zatvoriDB();