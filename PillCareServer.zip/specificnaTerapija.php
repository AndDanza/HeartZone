<?php
    include("baza.class.php");
	
    $veza = new Baza();
    $veza->spojiDB();
	
	$user = json_decode($_GET["user"]);
	$medicament = json_decode($_GET["medicament"]);
	
    $podaci = array();
    
    if(isset($user) && isset($medicament)){
        $sql="SELECT `id`, `lijek_id`, `korisnik_id`, `pocetak`, `kraj`, `pojedinacna_doza`, `broj_dnevnih_doza`, `upozorenje`, `razmak_dnevnih_doza`, `stanje` FROM `terapija` WHERE `lijek_id` = $medicament->id AND `korisnik_id` = $user->id AND `kraj` IS NULL";
            
        $rezultat = $veza->selectDB($sql);
        $red = $rezultat->fetch_array();
        $podaci["id"] = $red["id"];
        $podaci["lijekoviId"] = $red["lijek_id"];
        $podaci["korisnikId"] = $red["korisnik_id"];
		$podaci["pocetak"] = $red["pocetak"];
		$podaci["kraj"] = $red["kraj"];
		$podaci["pojedinacnaDoza"] = $red["pojedinacna_doza"];
		$podaci["upozorenje"] = $red["upozorenje"];
		$podaci["razmakDnevnihDoza"] = $red["razmak_dnevnih_doza"];
		$podaci["brojDnevnihDoza"] = $red["broj_dnevnih_doza"];
		$podaci["stanje"] = $red["stanje"];
        if (json_encode($podaci)!='[]'){
            echo json_encode($podaci,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        }
        else{
            header('HTTP/1.1 400 Bad request', true, 400);
        }
    }
    $veza->zatvoriDB();