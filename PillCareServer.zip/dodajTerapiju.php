<?php
    include("baza.class.php");
    $veza = new Baza();
    $veza->spojiDB();
    $terapija = json_decode($_GET['therapy']);
    if(isset($terapija)){
        $sql = "INSERT INTO `terapija`(`lijek_id`, `korisnik_id`, `pojedinacna_doza`, `broj_dnevnih_doza`, `upozorenje`, `razmak_dnevnih_doza`, `stanje`) 
		VALUES ($terapija->lijekoviId, $terapija->korisnikId, $terapija->pojedinacnaDoza, $terapija->brojDnevnihDoza, $terapija->upozorenje, $terapija->razmakDnevnihDoza, 
		(SELECT `broj_tableta` FROM `lijek` WHERE `id` = $terapija->lijekoviId))";
        $rezultat = $veza->updateDB($sql);
        if($veza->pogreskaDB()){
            header('HTTP/1.1 400 Bad request', true, 400);
        }
        else{
            header('HTTP/1.1 200 OK', true, 200);
            echo "{'response': '1'}";
        }
    }
    else{
        header('HTTP/1.1 400 Bad request', true, 400);
    }
    $veza->zatvoriDB();