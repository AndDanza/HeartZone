<?php
    include("baza.class.php");
	
    $veza = new Baza();
    $veza->spojiDB();
	
	$user = $_GET["user"];
	
    $podaci = array();
    $allData = array();
    
    if(isset($user)){
        $sql="SELECT `id`,`termin`,`biljeska`,`vrijeme_upozorenja`,`aktivan`, `korisnik_id`  FROM `pregled` 
        WHERE korisnik_id = (SELECT id FROM korisnik WHERE korisnicko_ime = '$user') and STR_TO_DATE(termin, '%d-%m-%Y')=CURDATE()";
    
        $rezultat = $veza->selectDB($sql);
        while ($red = $rezultat->fetch_array()) {
            $podaci["id"] = $red["id"];
            $podaci["termin"] = $red["termin"];
			$podaci["biljeska"] = $red["biljeska"];
			$podaci["vrijeme"] = $red["vrijeme_upozorenja"];
			$podaci["aktivan"] = $red["aktivan"];
			$podaci["korisnik_id"] = $red["korisnik_id"];
			
			$allData[] = $podaci;
        }
        
        if (json_encode($allData)!='[]'){
            echo json_encode($allData,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        }
        else{
            header('HTTP/1.1 400 Bad request', true, 400);
        }
    }
    $veza->zatvoriDB();